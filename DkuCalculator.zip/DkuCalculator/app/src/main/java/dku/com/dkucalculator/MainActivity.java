package dku.com.dkucalculator;

import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import InstanceSaver.SaveInstance;
import InstanceSaver.Saver;

public class MainActivity extends AppCompatActivity {

    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button button10;
    Button button11;
    Button button12;
    Button button13;
    Button button14;
    Button button15;
    Button button16;
    Button button17;

    @SaveInstance
    TextView lbl_calculator;

    @SaveInstance
    double numberOnScreen = 0;

    @SaveInstance
    double bufferResult = 0;

    @SaveInstance
    double result = 0;

    @SaveInstance
    boolean isTransactionButtonPressedBeforeExceptEqualsAndReset = false;

    @SaveInstance
    String bufferKeypad = "";

    @SaveInstance
    List<Double> arrayOfNumbers = new ArrayList<>();

    @SaveInstance
    List<Integer> tagKeeper = new ArrayList<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button0=findViewById(R.id.button0);
        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button6=findViewById(R.id.button6);
        button7=findViewById(R.id.button7);
        button8=findViewById(R.id.button8);
        button9=findViewById(R.id.button9);
        button10=findViewById(R.id.button10);
        button11=findViewById(R.id.button11);
        button12=findViewById(R.id.button12);
        button13=findViewById(R.id.button13);
        button14=findViewById(R.id.button14);
        button15=findViewById(R.id.button15);
        button16=findViewById(R.id.button16);
        button17=findViewById(R.id.button17);

        lbl_calculator=findViewById(R.id.lbl_calculator);

        button0.setTag(0);
        button1.setTag(1);
        button2.setTag(2);
        button3.setTag(3);
        button4.setTag(4);
        button5.setTag(5);
        button6.setTag(6);
        button7.setTag(7);
        button8.setTag(8);
        button9.setTag(9);
        button10.setTag(10);
        button11.setTag(11);
        button12.setTag(12);
        button13.setTag(13);
        button14.setTag(14);
        button15.setTag(15);
        button16.setTag(16);
        button17.setTag(17);

//       To be compatible under v25  , for uniform text
        TextViewCompat.setAutoSizeTextTypeWithDefaults(lbl_calculator, TextViewCompat.AUTO_SIZE_TEXT_TYPE_UNIFORM);
        clearAll();

    }

    public void numberPressed (View v) {



        //That control is executes to be able to see previous numbers on screen after press ant transaction button.
        if(isTransactionButtonPressedBeforeExceptEqualsAndReset ==true) {

            switch (v.getId()) {

                case R.id.button0:
                    bufferKeypad += "0";
                    break;

                case R.id.button1:
                    bufferKeypad += "1";
                    break;

                case R.id.button2:
                    bufferKeypad += "2";
                    break;

                case R.id.button3:
                    bufferKeypad += "3";
                    break;

                case R.id.button4:
                    bufferKeypad += "4";
                    break;

                case R.id.button5:
                    bufferKeypad += "5";
                    break;

                case R.id.button6:
                    bufferKeypad += "6";
                    break;

                case R.id.button7:
                    bufferKeypad += "7";
                    break;

                case R.id.button8:
                    bufferKeypad += "8";
                    break;

                case R.id.button9:
                    bufferKeypad += "9";
                    break;

                case R.id.button17:
                    if (!bufferKeypad.contains(".")) {
                        bufferKeypad += ".";
                    }
                    break;

                case R.id.button15:
                    clearAll();
                    break;

                default:
                    break;

            }

            lbl_calculator.setText(String.valueOf(""));
            lbl_calculator.setText(String.valueOf(bufferKeypad));

            if(v.getId() != R.id.button15 && !lbl_calculator.getText().toString().equals(".")) {

                numberOnScreen = Double.parseDouble(lbl_calculator.getText().toString());
            }
        }

        //To get First number after initialization
        else{

            switch (v.getId()) {

                case R.id.button0:
                    lbl_calculator.append("0");
                    break;

                case R.id.button1:
                    lbl_calculator.append("1");
                    break;

                case R.id.button2:
                    lbl_calculator.append("2");
                    break;

                case R.id.button3:
                    lbl_calculator.append("3");
                    break;

                case R.id.button4:
                    lbl_calculator.append("4");
                    break;

                case R.id.button5:
                    lbl_calculator.append("5");
                    break;

                case R.id.button6:
                    lbl_calculator.append("6");
                    break;

                case R.id.button7:
                    lbl_calculator.append("7");
                    break;

                case R.id.button8:
                    lbl_calculator.append("8");
                    break;

                case R.id.button9:
                    lbl_calculator.append("9");
                    break;

                case R.id.button17:
                    if (!lbl_calculator.getText().toString().contains(".")) {
                        lbl_calculator.append(".");
                    }
                   break;


                case R.id.button15:
                    clearAll();
                    break;

                default:
                    break;

            }



            if(v.getId() != R.id.button15 && !lbl_calculator.getText().toString().equals(".")) {

                numberOnScreen = Double.parseDouble(lbl_calculator.getText().toString());
            }

        }



    }


    public void transactionButtonPressed(View v){



        //Due to equals button and other buttons works differently , we should monitor user's moves.



        if(!lbl_calculator.getText().toString().equals("")){

            tagKeeper.add((int)v.getTag());

            //Button 16 is equal button.
            //This contol is for getting input for Equal button which lately push during using app. And if user want to enter a new number without pressing AC button.
            if(tagKeeper.size() >=2 && tagKeeper.get(tagKeeper.size()-2) == 16  && tagKeeper.get(tagKeeper.size()-1) != 16  && String.valueOf(result) != lbl_calculator.getText().toString()) {

                arrayOfNumbers.clear();
                bufferKeypad = "";
                arrayOfNumbers.add(0,Double.parseDouble(lbl_calculator.getText().toString()));
                isTransactionButtonPressedBeforeExceptEqualsAndReset = true;
                bufferResult = arrayOfNumbers.get(0);

            }

            //Used for to get first number of transaction.
            if(lbl_calculator.getText() != "" && arrayOfNumbers.size() == 0 && bufferResult == 0 && (v.getTag()==button10.getTag() || v.getTag()==button11.getTag() || v.getTag()==button12.getTag()  ||  v.getTag()==button13.getTag() || v.getTag()==button14.getTag())){

                arrayOfNumbers.add(0 , numberOnScreen);
                isTransactionButtonPressedBeforeExceptEqualsAndReset =true;

            }

            //Equals button
            else if(lbl_calculator.getText() != "" && arrayOfNumbers.size() == 1 && v.getTag()==button16.getTag()){

                //For first equals button , if there is not any other consecutive transactions before.
                if(bufferResult==0){
                    arrayOfNumbers.add(1,numberOnScreen);
                    additionalTransaction(tagKeeper.get(tagKeeper.size()-2));
                }

                else{
                    arrayOfNumbers.clear();
                    arrayOfNumbers.add(0 ,bufferResult);
                    arrayOfNumbers.add(1 ,numberOnScreen);
                    additionalTransaction(tagKeeper.get(tagKeeper.size()-2));
                }

            }


            //Send parameters if Equal button which lately push during using an App.
            else if(lbl_calculator.getText() != "" && arrayOfNumbers.size()==1 && tagKeeper.get(tagKeeper.size()-1) != 16 && tagKeeper.get(tagKeeper.size()-2) != 16 && numberOnScreen != 0){

                arrayOfNumbers.add(1 ,numberOnScreen);
                additionalTransaction((int)v.getTag());

            }

        }


    }




    public void additionalTransaction(int transaction){

        //Add
        if(transaction==10 ){
            result = arrayOfNumbers.get(0) + arrayOfNumbers.get(1);
        }

        //Subtract
        else if(transaction==11 ){
            result = arrayOfNumbers.get(0) - arrayOfNumbers.get(1);
        }

        //Multiply
        else if(transaction==12 ){
            result = arrayOfNumbers.get(0) * arrayOfNumbers.get(1);
        }

        //Divide
        else if(transaction==13 ){
            result = arrayOfNumbers.get(0) / arrayOfNumbers.get(1);

        }

        //Modulo
        else if(transaction==14 ){
            result = arrayOfNumbers.get(0) % arrayOfNumbers.get(1);
        }


        bufferResult=result;

        //Decimal control for proper presentation of numbers on screen
        if(result % 1 == 0){

            lbl_calculator.setText((String.valueOf(String.format("%.000f",bufferResult))));

        }

        else{
            lbl_calculator.setText((String.valueOf(String.format("%.6f",bufferResult))));
        }

        //These are prepare app to get new input.
        arrayOfNumbers.clear();
        arrayOfNumbers.add(0 , result);
        bufferKeypad = "";
        numberOnScreen = 0;
        isTransactionButtonPressedBeforeExceptEqualsAndReset = true;


    }




    public void clearAll(){

        arrayOfNumbers.clear();;
        result = 0;
        bufferKeypad = "";
        lbl_calculator.setText(String.valueOf(""));
        numberOnScreen = 0;
        isTransactionButtonPressedBeforeExceptEqualsAndReset = false ;

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Saver.save(outState,this);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Saver.load(savedInstanceState,this);

        //This is for first initialized or for number after pushing AC
        if(isTransactionButtonPressedBeforeExceptEqualsAndReset==false){
            if (numberOnScreen % 1 == 0) {

                lbl_calculator.setText((String.valueOf(String.format("%.000f", numberOnScreen))));

            } else {
                lbl_calculator.setText((String.valueOf(String.format("%.6f", numberOnScreen))));
            }

        }

        // This is for to transmit value if result is on the screen
        else if(bufferKeypad.equals("") && isTransactionButtonPressedBeforeExceptEqualsAndReset==true) {
            if (result % 1 == 0) {

                lbl_calculator.setText((String.valueOf(String.format("%.000f", bufferResult))));

            } else {
                lbl_calculator.setText((String.valueOf(String.format("%.6f", bufferResult))));
            }

        }
        //This only gets normal numbers pressed.
        else {
            lbl_calculator.setText(String.valueOf(bufferKeypad));
        }

    }
}
